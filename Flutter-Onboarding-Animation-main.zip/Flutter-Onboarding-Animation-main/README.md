# Flutter Onboarding Animation

## [Watch it on YouTube](https://youtu.be/1MyW5olYhiA)

Welcome to my 100-Second Animation Series, where I will showcase how to create intricate animations on Flutter in just 100 seconds. Let's start with this seamless sliding animation.

Big thanks to Guillaume Bernos for sharing this awesome animation with us!

![Preview](/gif.gif)

![App UI](/ui.png)
